module.exports = function (eleventyConfig) {
  // Copy the stylesheet (and any future images) straight through to the build.
  eleventyConfig.addPassthroughCopy({ "src/assets": "assets" });

  const MONTHS = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December",
  ];

  const toDate = (d) => (d instanceof Date ? d : new Date(d));

  // "June 9, 2026"
  eleventyConfig.addFilter("readableDate", (d) => {
    const t = toDate(d);
    return `${MONTHS[t.getUTCMonth()]} ${t.getUTCDate()}, ${t.getUTCFullYear()}`;
  });

  // "Jun 9"
  eleventyConfig.addFilter("shortDate", (d) => {
    const t = toDate(d);
    return `${MONTHS[t.getUTCMonth()].slice(0, 3)} ${t.getUTCDate()}`;
  });

  // ISO 8601 for the feed.
  eleventyConfig.addFilter("isoDate", (d) => toDate(d).toISOString());

  // "8 min read" estimate from rendered HTML.
  eleventyConfig.addFilter("readingTime", (html) => {
    const text = String(html || "").replace(/<[^>]+>/g, " ");
    const words = (text.match(/\b[\w’'-]+\b/g) || []).length;
    const mins = Math.max(1, Math.ceil(words / 200));
    return `${mins} min read`;
  });

  // Slug used for category URLs — must match the collection below.
  const slugify = (s) =>
    String(s)
      .toLowerCase()
      .trim()
      .replace(/&/g, " and ")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "");
  eleventyConfig.addFilter("catslug", slugify);

  // Newest-first copy of a list (never mutates the original collection).
  eleventyConfig.addFilter("newest", (arr) =>
    [...(arr || [])].sort((a, b) => b.date - a.date)
  );

  // Posts belonging to a given category name.
  eleventyConfig.addFilter("whereCategory", (posts, name) => {
    if (!name) return [];
    return (posts || []).filter(
      (p) => (p.data.categories || []).indexOf(name) !== -1
    );
  });

  // Drop a post by its URL (used to hide the current article from "related").
  eleventyConfig.addFilter("exclude", (arr, url) =>
    (arr || []).filter((p) => p.url !== url)
  );

  // First N items.
  eleventyConfig.addFilter("limit", (arr, n) => (arr || []).slice(0, n));

  // Build the unique list of categories with their posts, busiest first.
  eleventyConfig.addCollection("categoryList", (collectionApi) => {
    const posts = collectionApi.getFilteredByTag("posts");
    const map = {};
    posts.forEach((p) => {
      (p.data.categories || []).forEach((c) => {
        const slug = slugify(c);
        if (!map[slug]) map[slug] = { name: c, slug, posts: [] };
        map[slug].posts.push(p);
      });
    });
    return Object.keys(map)
      .map((k) => map[k])
      .sort((a, b) => b.posts.length - a.posts.length);
  });

  return {
    dir: {
      input: "src",
      includes: "_includes",
      data: "_data",
      output: "_site",
    },
    markdownTemplateEngine: "njk",
    htmlTemplateEngine: "njk",
    dataTemplateEngine: "njk",
  };
};
