---
layout: page.njk
title: "About Beyond the Numbers"
---
**Beyond the Numbers** is a daily journal of markets and macro — the analysis behind the headline figure, written for people who read the footnotes.

We cover monetary policy, equities, fixed income, currencies, and commodities, with a bias toward the second-order question: not just *what* moved, but *why it matters* for how capital is positioned.

## Editorial principles

- **Clarity over noise.** One well-argued idea beats ten recycled takes.
- **Show the reasoning.** Conclusions are only as good as the evidence behind them.
- **Respect the reader.** Our audience is professional; we write accordingly.

To get our flagship daily brief, *The Daily Close*, use the subscribe box in the sidebar.
