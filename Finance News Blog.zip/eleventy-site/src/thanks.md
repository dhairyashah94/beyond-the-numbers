---
layout: page.njk
title: "You're in."
eleventyExcludeFromCollections: true
---
Thanks for subscribing to **The Daily Close**. Look out for our next brief in your inbox.

[← Back to the front page](/)
