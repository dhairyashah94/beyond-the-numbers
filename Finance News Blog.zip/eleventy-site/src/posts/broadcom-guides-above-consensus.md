---
title: "Broadcom Guides Q3 Revenue Above Consensus on AI Networking Demand"
description: "The chipmaker pointed to accelerating orders for the switching silicon that ties AI clusters together."
date: 2026-06-05
author: "Marcus Lin"
authorRole: "Technology & Equities"
categories:
  - "Equities"
topics:
  - "Earnings"
  - "Semiconductors"
---
Broadcom guided third-quarter revenue above Wall Street estimates, crediting demand for the networking chips that connect the thousands of accelerators inside a modern AI training cluster. The networking story has become nearly as important as the accelerators themselves.

Management struck a confident tone on the durability of orders. Investors, having seen this film before, will want to see the backlog convert to shipments before extrapolating too far.
