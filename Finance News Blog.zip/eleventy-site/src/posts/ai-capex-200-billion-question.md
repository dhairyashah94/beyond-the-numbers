---
title: "The $200 Billion Question Hanging Over the AI Trade"
description: "Hyperscaler capital spending is breaking records. Investors are starting to ask when the returns arrive."
date: 2026-06-09
author: "Marcus Lin"
authorRole: "Technology & Equities"
categories:
  - "Equities"
topics:
  - "AI"
  - "Capex"
  - "Big Tech"
---
The four largest cloud providers will spend a combined $200 billion on capital expenditure this year, the bulk of it on the chips and data centers that train and serve artificial-intelligence models. It is one of the fastest corporate spending ramps in history. The question increasingly being asked on earnings calls is a simple one: where is the revenue?

For now, the spending is rewarded. Shares of the firms building the infrastructure have outpaced the broader market by a wide margin. But the pattern rhymes uncomfortably with previous technology build-outs, where the companies laying the track did not always capture the value of the traffic.

## The payback math

Depreciation is the quiet pressure point. A $200 billion asset base depreciated over six years is roughly $33 billion of annual cost that has to be earned back before a dollar of profit appears. Cloud revenue is growing, but not yet at a pace that closes that gap on the timeline some investors assume.

None of this means the trade is wrong. It means the margin of safety has thinned. When an entire sector is priced for flawless execution, the surprises tend to come from the downside.
