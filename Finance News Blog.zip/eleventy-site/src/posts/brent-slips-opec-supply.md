---
title: "Brent Slips Below $80 as OPEC+ Signals a Gradual Supply Return"
description: "Crude eased after the cartel indicated it would begin unwinding voluntary cuts later this year."
date: 2026-06-06
author: "Beyond the Numbers"
categories:
  - "Commodities"
topics:
  - "Oil"
  - "OPEC"
  - "Commodities"
---
Brent crude slipped below $80 a barrel after OPEC+ signaled it would begin returning voluntary production cuts to the market on a gradual schedule into the back half of the year. The move was telegraphed, but the confirmation was enough to take the edge off prices.

Demand signals remain mixed. Refining margins in Asia have firmed, while diesel consumption in Europe stays soft. The balance of risks for the second half tilts toward supply, not demand.
