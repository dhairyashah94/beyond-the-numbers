---
title: "Why 'Higher for Longer' Was Always a Floor, Not a Ceiling"
description: "The market spent a year treating the Fed's mantra as a worst case. It may have been a baseline."
date: 2026-06-04
author: "Eleanor Voss"
authorRole: "Chief Markets Correspondent"
categories:
  - "Opinion"
topics:
  - "Opinion"
  - "Monetary Policy"
---
For the better part of a year, "higher for longer" was treated as the hawkish scenario — the outcome to fear, the tail to hedge. That framing always struck me as backward. The phrase was never a threat. It was the central case.

Markets prefer a clean narrative: rates peak, rates fall, multiples re-rate. Reality is lumpier. An economy that refuses to slow gives a central bank no reason to ease, and every reason to wait.

## The cost of being early

Positioning for cuts that keep getting pushed out is expensive. It is the kind of mistake that does not look like a mistake until the carry has quietly bled away. The discipline is to take the committee at its word — even when its word is boring.
