---
title: "The Yen Carry Trade Is Back. So Is the Risk."
description: "A widening rate differential has revived a strategy that has burned investors before."
date: 2026-06-08
author: "Daniel Okafor"
authorRole: "FX & Rates"
categories:
  - "FX & Rates"
topics:
  - "Yen"
  - "Carry Trade"
  - "FX"
---
Borrow in a currency that costs almost nothing, invest in one that pays handsomely, and pocket the difference. The yen carry trade is the oldest idea in macro, and the widening gap between Japanese and U.S. rates has made it irresistible again.

It works beautifully until it does not. The strategy is, in effect, short volatility: steady gains punctuated by violent reversals when the funding currency snaps higher. Anyone who lived through past unwinds knows the speed involved.

## Watch the funding leg

The signal to respect is not the level of the differential but the stability of the yen itself. When positioning gets crowded and the currency starts to move, the exit is narrow and everyone heads for it at once.
