---
title: "The Fed Holds, but the Real Story Is in the Dots"
description: "Policymakers left rates unchanged for a seventh straight meeting. Buried in the projections is a quieter signal that the path to easing has narrowed — and markets may be mispricing it."
date: 2026-06-09
author: "Eleanor Voss"
authorRole: "Chief Markets Correspondent"
authorBio: "Eleanor covers central banks and global rates for Beyond the Numbers. She previously spent a decade on a sovereign rates desk."
categories:
  - "Monetary Policy"
topics:
  - "Federal Reserve"
  - "Rates"
  - "Monetary Policy"
  - "Treasuries"
---
The Federal Open Market Committee did exactly what futures markets expected on Wednesday, holding its benchmark rate in the 5.25%–5.50% range for a seventh consecutive meeting. The decision was unanimous. The press release was nearly unchanged. And for the first fifteen minutes, the market barely moved.

Then the projections landed. The so-called dot plot — the anonymous scatter of rate forecasts from each policymaker — told a story the statement was careful not to. Where officials had penciled in three cuts for the year back in March, the median now shows just one.

## A narrower path than the headlines suggest

It is tempting to read a single-cut median as hawkish. The more revealing detail is the distribution. Four members now see no cuts at all this year, up from two. The committee is not coalescing around a view; it is fracturing around one.

> The dispersion in the dots is the signal. A divided committee is a committee that will move late, and move reluctantly.

That matters for risk assets in a specific way. Equity multiples have expanded all year on the assumption that the cost of capital is about to fall. If the first cut slips from September to December — or into next year — the arithmetic of those multiples gets harder to defend.

## What the bond market is saying

The two-year Treasury yield, the maturity most sensitive to policy expectations, has climbed nearly 40 basis points since the spring. That is not the bond market betting on imminent easing. It is the bond market taking the committee at its word.

For investors, the takeaway is less about the June meeting than about positioning for a regime in which patience is the policy. The cuts will come. The question the dots are quietly asking is whether anyone is still early.
