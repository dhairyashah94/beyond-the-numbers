---
title: "The Passive Investing Bubble Is a Category Error"
description: "Critics keep predicting that index funds will break the market. They are looking at the wrong risk."
date: 2026-06-03
author: "Sofia Reyes"
authorRole: "Contributing Columnist"
categories:
  - "Opinion"
topics:
  - "Opinion"
  - "Markets"
---
Every few years a familiar warning resurfaces: passive investing has grown so large that it has broken price discovery, and the whole edifice is one shock away from collapse. It is a tidy story. It is also, I think, a category error.

Indexing does not set prices; active traders at the margin still do. What indexing changes is who bears the cost of being wrong, and how cheaply ordinary savers can own the market. Those are features, not bugs.

## The real risk is behavioral

If there is a danger, it is not mechanical but human: the temptation to abandon a low-cost, diversified plan at precisely the wrong moment. The structure is sound. The investor is the variable.
