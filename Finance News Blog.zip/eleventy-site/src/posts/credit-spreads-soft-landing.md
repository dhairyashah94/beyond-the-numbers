---
title: "Credit Spreads Are Pricing a Soft Landing. History Disagrees."
description: "High-yield spreads sit near cycle tights even as default rates tick upward."
date: 2026-06-08
author: "Priya Anand"
authorRole: "Fixed Income"
categories:
  - "Fixed Income"
topics:
  - "Credit"
  - "High Yield"
  - "Spreads"
---
The spread between high-yield corporate bonds and Treasuries has compressed to levels last seen before the previous tightening cycle. On its face, that is a vote of confidence: investors are demanding very little extra compensation to lend to riskier companies.

The trouble is what sits underneath. Trailing default rates have edged higher for three consecutive quarters, and the share of issuers rated triple-C has grown. Tight spreads and rising defaults are not a combination that usually persists.

## A coiled spring

Credit markets tend to move slowly and then all at once. The repricing, when it comes, rarely waits for a recession to be confirmed. For allocators, the asymmetry is the point: the upside from here is a few more basis points of carry, while the downside is a gap that can open in days.
