# Beyond the Numbers — your blog

This is your finance blog as a **static website**: fast, secure, and **free to host**.
You write each post as a simple text file; the site rebuilds itself into the
design you approved. No WordPress, no monthly fees, no servers to manage.

It's built with **[Eleventy](https://www.11ty.dev/)** (a static-site generator).
You don't need to understand Eleventy to use it — just follow the steps below.

---

## What you get

- A homepage with a lead story, a **Latest** grid, an **In Brief** rail, and an **Opinion** section — all filled automatically from your posts.
- Article pages, category pages, an **RSS feed**, and a working **newsletter sign-up** (free, via Netlify Forms).
- The exact navy-and-gold editorial design, every page.

---

## Part 1 — Put the site online (one time, ~15 minutes, free)

You'll use two free accounts: **GitHub** (stores your files) and **Netlify**
(builds and hosts the site, free forever for a blog this size).

### Step 1 — Create a free GitHub account
Go to **https://github.com** and sign up. No payment, ever, for this.

### Step 2 — Create a repository and upload these files
1. On GitHub click the **+** (top right) → **New repository**.
2. Name it `beyond-the-numbers`, leave it Public, click **Create repository**.
3. On the new repo page click **uploading an existing file**.
4. Drag in **everything inside this `eleventy-site` folder** (the `src` folder,
   `.eleventy.js`, `package.json`, `netlify.toml`, etc.). *Tip: upload the
   contents of the folder, not the folder itself.*
5. Click **Commit changes**.

### Step 3 — Connect Netlify (this builds + hosts the site)
1. Go to **https://netlify.com** → **Sign up** → choose **Sign up with GitHub**.
2. Click **Add new site → Import an existing project → Deploy with GitHub**.
3. Authorize Netlify, then pick your `beyond-the-numbers` repository.
4. Netlify reads `netlify.toml` and fills in the settings automatically
   (Build command `npm run build`, Publish directory `_site`). Just click **Deploy**.
5. Wait ~1 minute. Netlify gives you a live URL like
   `https://beyondthenumbers.netlify.app`. **You're live.** 🎉

> You can rename that address in Netlify under **Site configuration → Change site name**,
> or connect a custom domain later (the only thing that ever costs money).

---

## Part 2 — Publish a post (your daily routine)

You can do this **entirely in your web browser** — nothing to install.

1. On GitHub, open the **`src/posts`** folder.
2. Click **Add file → Create new file**.
3. Name it with words and a `.md` ending, e.g. `markets-wobble-on-cpi.md`.
4. Paste this template and edit it:

```markdown
---
title: "Your Headline Goes Here"
description: "One or two sentences that appear under the headline and on cards."
date: 2026-06-10
author: "Your Name"
authorRole: "Markets Reporter"
categories:
  - "Markets"
topics:
  - "Inflation"
  - "Equities"
---
Write your article here in plain text. Leave a blank line between paragraphs.

## A subheading

> A sentence in this style becomes a pull-quote.

Keep writing. When you're done, scroll down and commit.
```

5. Scroll down, click **Commit changes**.
6. Netlify notices the change and **rebuilds the site automatically** in about
   30 seconds. Refresh your site — your newest post is now the lead story.

That's the whole loop: **add a file → commit → it's live.**

### The front-matter fields (the part between the `---` lines)

| Field | Required? | What it does |
|---|---|---|
| `title` | yes | The headline. |
| `description` | recommended | The standfirst/deck under the headline and on cards. |
| `date` | yes | `YYYY-MM-DD`. Newest date becomes the lead story. |
| `author` | optional | Byline name. Defaults to the site name. |
| `authorRole` | optional | Shown in the author box at the foot of the article. |
| `authorBio` | optional | A sentence about the author. |
| `categories` | recommended | The **first** one is the gold label + drives the top nav and category pages. Use `Opinion` to feed the homepage Opinion strip. |
| `topics` | optional | Tag chips at the foot of the article. |
| `image` | optional | Path to a featured image (see below). |
| `imageCredit` | optional | Photo credit under the hero image. |

### Adding images
1. Put image files in **`src/assets`** (upload them on GitHub the same way).
2. Reference one in a post's front matter: `image: "/assets/my-photo.jpg"`.
   Posts with no image get a tasteful branded placeholder.

---

## Part 3 — Make it yours

- **Site name, tagline, footer:** edit **`src/_data/site.json`**. Set `url` to your
  real Netlify address so the RSS feed and share links are correct.
- **The top menu** is built automatically from your categories (busiest first).
  Create posts in the categories you want to appear.
- **About page:** edit **`src/about.md`**.
- **Newsletter sign-ups** land in your Netlify dashboard under **Forms** (free).
  To send actual emails, connect the form to Mailchimp/Substack later — ask if
  you'd like help.

---

## Optional — preview on your own computer

Not required (GitHub + Netlify do everything), but if you want a local preview:

1. Install **Node.js** (LTS) from https://nodejs.org.
2. Open a terminal in this folder and run:
   ```
   npm install
   npm start
   ```
3. Open the address it prints (usually `http://localhost:8080`).

---

## File map

```
eleventy-site/
├─ .eleventy.js        Build config (filters, category pages)
├─ package.json        Dependencies + scripts
├─ netlify.toml        Tells Netlify how to build
├─ src/
│  ├─ _data/site.json  Your site name, tagline, URL
│  ├─ _includes/       Page layouts + reusable parts
│  ├─ assets/style.css The design
│  ├─ posts/           Your articles (Markdown) ← you mostly work here
│  ├─ index.njk        Homepage
│  ├─ categories.njk   Auto category pages
│  ├─ feed.njk         RSS feed
│  ├─ about.md         About page
│  └─ thanks.md        Newsletter "thank you" page
└─ _site/              The built website (created automatically; not edited)
```

Questions or want help with a custom domain or email newsletter? Just ask.
